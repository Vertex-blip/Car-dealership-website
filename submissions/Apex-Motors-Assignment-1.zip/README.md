﻿# Apex Motors - Assignment 1

Team Apex Motors, Group SE-2507.

This archive is a self-contained, framework-free website with nine HTML pages, `css/style.css`, and local images. Open `index.html` directly or run `python -m http.server 8000` in this folder and visit `http://localhost:8000/`.

The live cumulative project is at https://vertex-blip.github.io/Car-dealership-website/ . The contact form is a browser-only demonstration and does not send or store personal information.

Team: Arsen, Kuttibay, Farabi, and Muhammad.
